@extends('layouts.master')
@section('title')
@lang('translation.Unicons')
@endsection

@section('content')
@component('common-components.breadcrumb')
    @slot('pagetitle') Icons @endslot
    @slot('title') Unicons @endslot
@endcomponent
@endsection
